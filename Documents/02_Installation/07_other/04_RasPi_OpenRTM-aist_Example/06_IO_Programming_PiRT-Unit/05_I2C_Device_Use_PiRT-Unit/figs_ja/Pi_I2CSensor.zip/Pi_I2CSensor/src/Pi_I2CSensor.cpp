// -*- C++ -*-
/*!
 * @file  Pi_I2CSensor.cpp
 * @brief Using RaspberryPi's I2C port, get 9 datas (3 axis x 3 sensors) @ 2013/06/07
 * @date $Date$
 *
 * $Id$
 */

#include "Pi_I2CSensor.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

#include <linux/i2c-dev.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#include <wiringPi.h>

#define L3GD20	0x6a
#define LSM303DLHCA 0x19
#define LSM303DLHCM 0x1e

int i2c_fd;       // �f�o�C�X�t�@�C���p�t�@�C���f�B�X�N���v�^
//char *i2cFileName = "/dev/i2c-0"; // I2C�f�o�C�X�t�@�C����
char *i2cFileName = "/dev/i2c-1"; // RaspberryPi�̃��r�W�����ɍ��킹�ĕύX
int i2cAddress; // I2C�A�h���X�w��p
int gyroData[3]; // �W���C��3���ix,y,z�j�f�[�^�i�[�p
int acceleData[3]; // �����x3���ix,y,z�j�f�[�^�i�[�p
int geomagData[3]; // �n���C3���ix,y,z�j�f�[�^�i�[�p

void I2C_write(unsigned char address, unsigned char data, int fd){
	unsigned char buf[2];
	buf[0] = address;
	buf[1] = data;
	if((write(fd,buf,2))!=2){
		printf("Error writing to i2c slave\n");
	}
	return;
}
unsigned char I2C_read(unsigned char address, int fd){
	unsigned char buf[1];
	buf[0] = address;
	if((write(fd,buf,1))!= 1){ // address����x�������ޏ��ɒ���
		printf("Error writing to i2c slave\n");
	}
	if(read(fd,buf,1)!=1){
		printf("Error reading from i2c slave\n");
	}
	return buf[0];
}

// Module specification
// <rtc-template block="module_spec">
static const char* pi_i2csensor_spec[] =
  {
    "implementation_id", "Pi_I2CSensor",
    "type_name",         "Pi_I2CSensor",
    "description",       "Using RaspberryPi's I2C port, get 9 datas (3 axis x 3 sensors) @ 2013/06/07",
    "version",           "1.0.0",
    "vendor",            "Sekiyama, AIST",
    "category",          "RTRoom",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "1",
    "language",          "C++",
    "lang_type",         "compile",
    ""
  };
// </rtc-template>

/*!
 * @brief constructor
 * @param manager Maneger Object
 */
Pi_I2CSensor::Pi_I2CSensor(RTC::Manager* manager)
    // <rtc-template block="initializer">
  : RTC::DataFlowComponentBase(manager),
    m_AcceleXOut("AcceleXOut", m_AcceleX),
    m_AcceleYOut("AcceleYOut", m_AcceleY),
    m_AcceleZOut("AcceleZOut", m_AcceleZ),
    m_GeomagXOut("GeomagXOut", m_GeomagX),
    m_GeomagYOut("GeomagYOut", m_GeomagY),
    m_GeomagZOut("GeomagZOut", m_GeomagZ),
    m_GyroXOut("GyroXOut", m_GyroX),
    m_GyroYOut("GyroYOut", m_GyroY),
    m_GyroZOut("GyroZOut", m_GyroZ)

    // </rtc-template>
{
}

/*!
 * @brief destructor
 */
Pi_I2CSensor::~Pi_I2CSensor()
{
}



RTC::ReturnCode_t Pi_I2CSensor::onInitialize()
{
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers
  
  // Set OutPort buffer
  addOutPort("AcceleXOut", m_AcceleXOut);
  addOutPort("AcceleYOut", m_AcceleYOut);
  addOutPort("AcceleZOut", m_AcceleZOut);
  addOutPort("GeomagXOut", m_GeomagXOut);
  addOutPort("GeomagYOut", m_GeomagYOut);
  addOutPort("GeomagZOut", m_GeomagZOut);
  addOutPort("GyroXOut", m_GyroXOut);
  addOutPort("GyroYOut", m_GyroYOut);
  addOutPort("GyroZOut", m_GyroZOut);
  
  // Set service provider to Ports
  
  // Set service consumers to Ports
  
  // Set CORBA Service Ports
  
  // </rtc-template>

  // <rtc-template block="bind_config">
  // </rtc-template>
	// I2C�f�o�C�X�t�@�C�����I�[�v��
	unsigned char Data;
	if ((i2c_fd = open(i2cFileName, O_RDWR)) < 0) 
	{
		printf("Faild to open i2c port\n");
		return RTC::RTC_ERROR;
	}
	// I2C�f�o�C�X�̓�����m�F�E�W���C���Z���T��������
	i2cAddress = L3GD20;
	if (ioctl(i2c_fd, I2C_SLAVE, i2cAddress) < 0) 
	{
		printf("Unable to get bus access to talk to slave\n");
		return RTC::RTC_ERROR;
	}
	printf("L3GD20 init seq. start\n");
	// L3GD20 ����m�F
	// L3GD20��0x0f���W�X�^�͏��0xd4�ɃZ�b�g����Ă��邽�ߓ���m�F���ł���
	Data = I2C_read(0x0f,i2c_fd);
	if(Data != 0xd4){
		printf("L3GD20 is not working\n");
		return RTC::RTC_ERROR;
	}
	delay(10);
	// ���W�X�^�ւ̏������݃`�F�b�N�ƃC�j�V�����C�Y�𓯎��ɍs��
	printf("L3GD20: read OK, Now writing check...\n");
	// 0x20���W�X�^��0x0f���������ނ��Ƃœ��삳����
	I2C_write(0x20, 0x0f, i2c_fd);
	// 0x20���W�X�^�Ɏ��ۂ�0x0f�������ꂽ���m�F
	Data = I2C_read(0x20,i2c_fd);
	if(Data != 0x0f){
		printf("Writing miss\n");
		return RTC::RTC_ERROR;
	} 
	delay(10);

	// �����x�Z���T��������
	i2cAddress = LSM303DLHCA;
	if (ioctl(i2c_fd, I2C_SLAVE, i2cAddress) < 0) 
	{
		printf("Unable to get bus access to talk to slave\n");
		return RTC::RTC_ERROR;
	}
	// LSM303DLHCA Init
	printf("LSM303DLHC_A checking. Now writing check...\n");
	I2C_write(0x20, 0x27, i2c_fd);
	Data = I2C_read(0x20,i2c_fd);
	if(Data != 0x27){
		printf("Writing miss\n");
		return RTC::RTC_ERROR;
	} 
	delay(10);

	// �n���C�Z���T��������
	i2cAddress = LSM303DLHCM;
	if (ioctl(i2c_fd, I2C_SLAVE, i2cAddress) < 0) 
	{
		printf("Unable to get bus access to talk to slave\n");
		return RTC::RTC_ERROR;
	}
	// LSM303DLHCM Init
	printf("LSM303DLHC_M checking. Now writing check...\n");
	I2C_write(0x00, 0x14, i2c_fd);
	delay(20);
	I2C_write(0x01, 0x20, i2c_fd);
	delay(20);
	I2C_write(0x02, 0x00, i2c_fd);
	delay(20);
	Data = I2C_read(0x02, i2c_fd);
	if(Data != 0x00){
		printf("Writing miss\n");
		return RTC::RTC_ERROR;
	} 
	delay(10);
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t Pi_I2CSensor::onFinalize()
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Pi_I2CSensor::onStartup(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Pi_I2CSensor::onShutdown(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Pi_I2CSensor::onActivated(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Pi_I2CSensor::onDeactivated(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/


RTC::ReturnCode_t Pi_I2CSensor::onExecute(RTC::UniqueId ec_id)
{
	unsigned char data[6];
	int i;
	// �W���C���f�[�^�ǂݍ���
	i2cAddress = L3GD20;
	if (ioctl(i2c_fd, I2C_SLAVE, i2cAddress) >= 0) {
		for(i=0; i<6; i++){
			data[i]=I2C_read(0x28+i,i2c_fd);
		}
		gyroData[0]=((int)data[1]<<24|(int)data[0]<<16)>>16;
		gyroData[1]=((int)data[3]<<24|(int)data[2]<<16)>>16;
		gyroData[2]=((int)data[5]<<24|(int)data[4]<<16)>>16;
	}
	delay(10);
	// �����x�f�[�^�ǂݍ���
	i2cAddress = LSM303DLHCA;
	if (ioctl(i2c_fd, I2C_SLAVE, i2cAddress) >= 0) {
		for(i=0; i<6; i++){
			data[i]=I2C_read(0x28+i,i2c_fd);
		}
		acceleData[0]=((int)data[1]<<24|(int)data[0]<<16)>>20;
		acceleData[1]=((int)data[3]<<24|(int)data[2]<<16)>>20;
		acceleData[2]=((int)data[5]<<24|(int)data[4]<<16)>>20;
	}
	// �n���C�f�[�^�ǂݍ���
	i2cAddress = LSM303DLHCM;
	if (ioctl(i2c_fd, I2C_SLAVE, i2cAddress) >= 0) {
		for(i=0; i<6; i++){
			data[i]=I2C_read(0x03+i,i2c_fd);
		}
		geomagData[0]=((int)data[0]<<24|(int)data[1]<<16)>>20;
		geomagData[1]=((int)data[4]<<24|(int)data[5]<<16)>>20;
		geomagData[2]=((int)data[2]<<24|(int)data[3]<<16)>>20;
	}
	// �f�[�^�|�[�g�����o��
	m_GyroX.data=gyroData[0];m_GyroXOut.write();
	m_GyroY.data=gyroData[1];m_GyroYOut.write();
	m_GyroZ.data=gyroData[2];m_GyroZOut.write();
	m_AcceleX.data=acceleData[0];m_AcceleXOut.write();
	m_AcceleY.data=acceleData[1];m_AcceleYOut.write();
	m_AcceleZ.data=acceleData[2];m_AcceleZOut.write();
	m_GeomagX.data=geomagData[0];m_GeomagXOut.write();
	m_GeomagY.data=geomagData[1];m_GeomagYOut.write();
	m_GeomagZ.data=geomagData[2];m_GeomagZOut.write();
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t Pi_I2CSensor::onAborting(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Pi_I2CSensor::onError(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Pi_I2CSensor::onReset(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Pi_I2CSensor::onStateUpdate(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Pi_I2CSensor::onRateChanged(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/



extern "C"
{
 
  void Pi_I2CSensorInit(RTC::Manager* manager)
  {
    coil::Properties profile(pi_i2csensor_spec);
    manager->registerFactory(profile,
                             RTC::Create<Pi_I2CSensor>,
                             RTC::Delete<Pi_I2CSensor>);
  }
  
};


