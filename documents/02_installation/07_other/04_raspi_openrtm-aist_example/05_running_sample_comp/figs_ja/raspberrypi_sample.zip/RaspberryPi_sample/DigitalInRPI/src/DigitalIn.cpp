// -*- C++ -*-
/*!
 * @file  DigitalIn.cpp
 * @brief Digital In Sample for Raspberry Pi
 * @date $Date$
 *
 * $Id$
 */

#include "DigitalIn.h"
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>

#define BCM2708_PERI_BASE        0x20000000
#define GPIO_BASE                (BCM2708_PERI_BASE + 0x200000) /* GPIO controller */

#define PAGE_SIZE (4*1024)
#define BLOCK_SIZE (4*1024)

// GPIO setup macros. Always use INP_GPIO(x) before using OUT_GPIO(x) or SET_GPIO_ALT(x,y)
#define INP_GPIO(g) *(gpio+((g)/10)) &= ~(7<<(((g)%10)*3))
#define OUT_GPIO(g) *(gpio+((g)/10)) |=  (1<<(((g)%10)*3))
#define SET_GPIO_ALT(g,a) *(gpio+(((g)/10))) |= (((a)<=3?(a)+4:(a)==4?3:2)<<(((g)%10)*3))

#define GPIO_SET *(gpio+7)  // sets   bits which are 1 ignores bits which are 0
#define GPIO_CLR *(gpio+10) // clears bits which are 1 ignores bits which are 0

// Module specification
// <rtc-template block="module_spec">
static const char* digitalin_spec[] =
  {
    "implementation_id", "DigitalIn",
    "type_name",         "DigitalIn",
    "description",       "Digital In Sample for Raspberry Pi",
    "version",           "0.0.1",
    "vendor",            "AIST",
    "category",          "Sample",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "1",
    "language",          "C++",
    "lang_type",         "compile",
    // Configuration variables
    "conf.default.PortNo", "17",
    // Widget
    "conf.__widget__.PortNo", "text",
    // Constraints
    ""
  };
// </rtc-template>

/*!
 * @brief constructor
 * @param manager Maneger Object
 */
DigitalIn::DigitalIn(RTC::Manager* manager)
    // <rtc-template block="initializer">
  : RTC::DataFlowComponentBase(manager),
    m_inIn("in", m_in)

    // </rtc-template>
{
}

/*!
 * @brief destructor
 */
DigitalIn::~DigitalIn()
{
}



RTC::ReturnCode_t DigitalIn::onInitialize()
{
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers
  addInPort("in", m_inIn);

  // Set OutPort buffer

  // Set service provider to Ports

  // Set service consumers to Ports

  // Set CORBA Service Ports

  // </rtc-template>

  // <rtc-template block="bind_config">
  // Bind variables and configuration variable
  bindParameter("PortNo", m_PortNo, "17");
  // </rtc-template>

  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t DigitalIn::onFinalize()
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t DigitalIn::onStartup(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t DigitalIn::onShutdown(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*!
 * GPIOポートの初期化
 */

RTC::ReturnCode_t DigitalIn::onActivated(RTC::UniqueId ec_id)
{
	if( setup_io()==false ) {
		return RTC::RTC_ERROR;
	}

	INP_GPIO(m_PortNo); // must use INP_GPIO before we can use OUT_GPIO
	OUT_GPIO(m_PortNo);

	return RTC::RTC_OK;
}


/*!
 * GPIOポートの停止
 */

RTC::ReturnCode_t DigitalIn::onDeactivated(RTC::UniqueId ec_id)
{
	GPIO_CLR = 1<<m_PortNo;

	return RTC::RTC_OK;
}


/*!
 * GPIOへのデータ出力
 */

RTC::ReturnCode_t DigitalIn::onExecute(RTC::UniqueId ec_id)
{
	if( m_inIn.isNew() ) {
		m_inIn.read();
		if( m_in.data ) {
			GPIO_SET = 1<<m_PortNo;
		} else {
			GPIO_CLR = 1<<m_PortNo;
		}
	}
	return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t DigitalIn::onAborting(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t DigitalIn::onError(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t DigitalIn::onReset(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t DigitalIn::onStateUpdate(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t DigitalIn::onRateChanged(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/


bool DigitalIn::setup_io() {
	/* open /dev/mem */
	if ((mem_fd = open("/dev/mem", O_RDWR|O_SYNC) ) < 0) {
		printf("can't open /dev/mem \n");
		return false;
	}
	printf("open /dev/mem \n");

	/* mmap GPIO */
	gpio_map = (char *)mmap(
		NULL,             //Any adddress in our space will do
		BLOCK_SIZE,       //Map length
		PROT_READ|PROT_WRITE,// Enable reading & writting to mapped memory
		MAP_SHARED,       //Shared with other processes
		mem_fd,           //File to map
		GPIO_BASE         //Offset to GPIO peripheral
	);
	close(mem_fd); //No need to keep mem_fd open after mmap

	if ((long)gpio_map < 0) {
		printf("mmap error %d\n", (int)gpio_map);
		return false;
	}
	printf("nmap ok \n");

	// Always use volatile pointer!
	gpio = (volatile unsigned *)gpio_map;

	return true;
}

extern "C"
{

  void DigitalInInit(RTC::Manager* manager)
  {
    coil::Properties profile(digitalin_spec);
    manager->registerFactory(profile,
                             RTC::Create<DigitalIn>,
                             RTC::Delete<DigitalIn>);
  }

};


