// -*- C++ -*-
/*!
 * @file  DigitalOut.cpp
 * @brief Digital Out Sample for Raspberry Pi
 * @date $Date$
 *
 * $Id$
 */

#define BCM2708_PERI_BASE        0x20000000
#define GPIO_BASE                (BCM2708_PERI_BASE + 0x200000) /* GPIO controller */

#include "DigitalOut.h"
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>

#define PAGE_SIZE (4*1024)
#define BLOCK_SIZE (4*1024)

#define INP_GPIO(g) *(gpio+((g)/10)) &= ~(7<<(((g)%10)*3))
#define OUT_GPIO(g) *(gpio+((g)/10)) |=  (1<<(((g)%10)*3))
#define SET_GPIO_ALT(g,a) *(gpio+(((g)/10))) |= (((a)<=3?(a)+4:(a)==4?3:2)<<(((g)%10)*3))

#define GPIO_SET *(gpio+7)  // sets   bits which are 1 ignores bits which are 0
#define GPIO_CLR *(gpio+10) // clears bits which are 1 ignores bits which are 0
#define GPIO_GET * (gpio+13)

// Module specification
// <rtc-template block="module_spec">
static const char* digitalout_spec[] =
  {
    "implementation_id", "DigitalOut",
    "type_name",         "DigitalOut",
    "description",       "Digital Out Sample for Raspberry Pi",
    "version",           "0.0.1",
    "vendor",            "AIST",
    "category",          "Sample",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "1",
    "language",          "C++",
    "lang_type",         "compile",
    // Configuration variables
    "conf.default.PortNo", "17",
    // Widget
    "conf.__widget__.PortNo", "text",
    // Constraints
    ""
  };
// </rtc-template>

/*!
 * @brief constructor
 * @param manager Maneger Object
 */
DigitalOut::DigitalOut(RTC::Manager* manager)
    // <rtc-template block="initializer">
  : RTC::DataFlowComponentBase(manager),
    m_outOut("out", m_out)

    // </rtc-template>
{
}

/*!
 * @brief destructor
 */
DigitalOut::~DigitalOut()
{
}



RTC::ReturnCode_t DigitalOut::onInitialize()
{
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers

  // Set OutPort buffer
  addOutPort("out", m_outOut);

  // Set service provider to Ports

  // Set service consumers to Ports

  // Set CORBA Service Ports

  // </rtc-template>

  // <rtc-template block="bind_config">
  // Bind variables and configuration variable
  bindParameter("PortNo", m_PortNo, "17");
  // </rtc-template>

  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t DigitalOut::onFinalize()
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t DigitalOut::onStartup(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t DigitalOut::onShutdown(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*!
 * GPIOポートの初期化
 */

RTC::ReturnCode_t DigitalOut::onActivated(RTC::UniqueId ec_id)
{
	if( setup_io()==false ) {
		return RTC::RTC_ERROR;
	}
	INP_GPIO(m_PortNo);

	return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t DigitalOut::onDeactivated(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*!
 * GPIOポートからのデータ読み込み
 */

RTC::ReturnCode_t DigitalOut::onExecute(RTC::UniqueId ec_id)
{
	if( gpio_read( m_PortNo ) ) {
		m_out.data = true;
	} else {
		m_out.data = false;
	}
	  m_outOut.write();

	  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t DigitalOut::onAborting(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t DigitalOut::onError(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t DigitalOut::onReset(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t DigitalOut::onStateUpdate(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t DigitalOut::onRateChanged(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

bool DigitalOut::setup_io() {
	if ((mem_fd = open("/dev/mem", O_RDWR|O_SYNC) ) < 0) {
		printf("can't open /dev/mem \n");
		return false;
	}
	printf("open /dev/mem \n");

	/* mmap GPIO */
	gpio_map = (char *)mmap(
		NULL,             //Any adddress in our space will do
		BLOCK_SIZE,       //Map length
		PROT_READ|PROT_WRITE,// Enable reading & writting to mapped memory
		MAP_SHARED,       //Shared with other processes
		mem_fd,           //File to map
		GPIO_BASE         //Offset to GPIO peripheral
	);
	close(mem_fd); //No need to keep mem_fd open after mmap

	if ((long)gpio_map < 0) {
		printf("mmap error %d\n", (int)gpio_map);
		return false;
	}
	printf("nmap ok \n");

	// Always use volatile pointer!
	gpio = (volatile unsigned *)gpio_map;

	return true;
}

bool DigitalOut::gpio_read(int port) {
	return((GPIO_GET & (1<<port)) ? false:true);
}

extern "C"
{

  void DigitalOutInit(RTC::Manager* manager)
  {
    coil::Properties profile(digitalout_spec);
    manager->registerFactory(profile,
                             RTC::Create<DigitalOut>,
                             RTC::Delete<DigitalOut>);
  }

};


