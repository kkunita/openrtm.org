// -*- C++ -*-
/*!
 * @file  Pi_SensorDataOutPut.cpp
 * @brief PrintOut Sensor Data on Console @ 2013/06/07
 * @date $Date$
 *
 * $Id$
 */

#include "Pi_SensorDataOutPut.h"

int gyroData[3]; // �W���C��3���ix,y,z�j�f�[�^�i�[�p
int acceleData[3]; // �����x3���ix,y,z�j�f�[�^�i�[�p
int geomagData[3]; // �n���C3���ix,y,z�j�f�[�^�i�[�p

// Module specification
// <rtc-template block="module_spec">
static const char* pi_sensordataoutput_spec[] =
  {
    "implementation_id", "Pi_SensorDataOutPut",
    "type_name",         "Pi_SensorDataOutPut",
    "description",       "PrintOut Sensor Data on Console @ 2013/06/07",
    "version",           "1.0.0",
    "vendor",            "Sekiyama, AIST",
    "category",          "RTRoom",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "1",
    "language",          "C++",
    "lang_type",         "compile",
    ""
  };
// </rtc-template>

/*!
 * @brief constructor
 * @param manager Maneger Object
 */
Pi_SensorDataOutPut::Pi_SensorDataOutPut(RTC::Manager* manager)
    // <rtc-template block="initializer">
  : RTC::DataFlowComponentBase(manager),
    m_AcceleXIn("AcceleXIn", m_AcceleX),
    m_AcceleYIn("AcceleYIn", m_AcceleY),
    m_AcceleZIn("AcceleZIn", m_AcceleZ),
    m_GeomagXIn("GeomagXIn", m_GeomagX),
    m_GeomagYIn("GeomagYIn", m_GeomagY),
    m_GeomagZIn("GeomagZIn", m_GeomagZ),
    m_GyroXIn("GyroXIn", m_GyroX),
    m_GyroYIn("GyroYIn", m_GyroY),
    m_GyroZIn("GyroZIn", m_GyroZ)

    // </rtc-template>
{
}

/*!
 * @brief destructor
 */
Pi_SensorDataOutPut::~Pi_SensorDataOutPut()
{
}



RTC::ReturnCode_t Pi_SensorDataOutPut::onInitialize()
{
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers
  addInPort("AcceleXIn", m_AcceleXIn);
  addInPort("AcceleYIn", m_AcceleYIn);
  addInPort("AcceleZIn", m_AcceleZIn);
  addInPort("GeomagXIn", m_GeomagXIn);
  addInPort("GeomagYIn", m_GeomagYIn);
  addInPort("GeomagZIn", m_GeomagZIn);
  addInPort("GyroXIn", m_GyroXIn);
  addInPort("GyroYIn", m_GyroYIn);
  addInPort("GyroZIn", m_GyroZIn);
  
  // Set OutPort buffer
  
  // Set service provider to Ports
  
  // Set service consumers to Ports
  
  // Set CORBA Service Ports
  
  // </rtc-template>

  // <rtc-template block="bind_config">
  // </rtc-template>
  
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t Pi_SensorDataOutPut::onFinalize()
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Pi_SensorDataOutPut::onStartup(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Pi_SensorDataOutPut::onShutdown(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Pi_SensorDataOutPut::onActivated(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Pi_SensorDataOutPut::onDeactivated(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/


RTC::ReturnCode_t Pi_SensorDataOutPut::onExecute(RTC::UniqueId ec_id)
{
	if((m_AcceleXIn.isNew())||(m_AcceleYIn.isNew())||(m_AcceleZIn.isNew())||
		(m_GeomagXIn.isNew())||(m_GeomagYIn.isNew())||(m_GeomagZIn.isNew())||
		(m_GyroXIn.isNew())||(m_GyroYIn.isNew())||(m_GyroZIn.isNew()))	
	{
		printf("AcceleData: X= ");
		m_AcceleXIn.read(); acceleData[0]=m_AcceleX.data; printf("%d Y= ",acceleData[0]);
		m_AcceleYIn.read(); acceleData[1]=m_AcceleY.data; printf("%d Z= ",acceleData[1]);
		m_AcceleZIn.read(); acceleData[2]=m_AcceleZ.data; printf("%d :",acceleData[2]);
		printf("GeomagData: X= ");
		m_GeomagXIn.read(); geomagData[0]=m_GeomagX.data; printf("%d Y= ",geomagData[0]);
		m_GeomagYIn.read(); geomagData[1]=m_GeomagY.data; printf("%d Z= ",geomagData[1]);
		m_GeomagZIn.read(); geomagData[2]=m_GeomagZ.data; printf("%d :",geomagData[2]);
		printf("GyroData: X= ");
		m_GyroXIn.read(); gyroData[0]=m_GyroX.data; printf("%d Y= ",gyroData[0]);
		m_GyroYIn.read(); gyroData[1]=m_GyroY.data; printf("%d Z= ",gyroData[1]);
		m_GyroZIn.read(); gyroData[2]=m_GyroZ.data; printf("%d\n",gyroData[2]);
	}
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t Pi_SensorDataOutPut::onAborting(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Pi_SensorDataOutPut::onError(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Pi_SensorDataOutPut::onReset(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Pi_SensorDataOutPut::onStateUpdate(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Pi_SensorDataOutPut::onRateChanged(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/



extern "C"
{
 
  void Pi_SensorDataOutPutInit(RTC::Manager* manager)
  {
    coil::Properties profile(pi_sensordataoutput_spec);
    manager->registerFactory(profile,
                             RTC::Create<Pi_SensorDataOutPut>,
                             RTC::Delete<Pi_SensorDataOutPut>);
  }
  
};


